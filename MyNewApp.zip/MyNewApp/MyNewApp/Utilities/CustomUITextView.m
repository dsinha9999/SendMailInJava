//
//  CustomUITextView.m
//  MyNewApp
//
//  Created by Dharmendra Sinha on 25/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import "CustomUITextView.h"

@implementation CustomUITextView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void) awakeFromNib
{
    [super awakeFromNib];
    if(self)
    {
        self.layer.borderColor = [UIColor blackColor].CGColor;
        self.layer.cornerRadius = 10;
        self.layer.borderWidth = 2.0f;
        
        
    }
}
@end
