//
//  CustomUITextField.m
//  MyNewApp
//
//  Created by Dharmendra Sinha on 25/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import "CustomUITextField.h"

@implementation CustomUITextField

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(void) awakeFromNib{
    
    [super awakeFromNib];
    if(self)
    {
        self.layer.borderWidth = 1.0f;
        self.layer.borderColor = [UIColor blackColor].CGColor;
        self.layer.cornerRadius = 10;
        UIView *textField = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 0)];
        self.leftView = textField;
        self.leftViewMode = UITextFieldViewModeAlways;
        //self.rightView = textField;
        //self.rightViewMode = UITextFieldViewModeAlways;
        //self.rightViewMode = UITextFieldViewModeAlways;
        //self.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"apple1.jpg"]];
        //self.leftViewMode = UITextFieldViewModeAlways;
        //self.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"apple1.jpg"]];
    }
}

@end
