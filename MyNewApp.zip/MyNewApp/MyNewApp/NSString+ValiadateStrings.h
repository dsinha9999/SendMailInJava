//
//  NSString+ValiadateStrings.h
//  MyNewApp
//
//  Created by Dharmendra Sinha on 28/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ValiadateStrings)
-(BOOL) isValidEmail : (NSString *_Nullable)email rangee:(NSRange)range emailLength:(NSInteger)length reqString:(nonnull NSString *)reqString;
-(BOOL) isValidName : (NSString *_Nullable)name rangee:(NSRange)range nameLength:(NSInteger)length reqString:(nonnull NSString *)reqString;
-(BOOL) isMobileNumberValid : (NSString *_Nullable)mobile rangee:(NSRange)range mobileLength:(NSInteger)length reqString:(nonnull NSString *)reqString;
-(BOOL) isValidPassword : (NSString *_Nullable)password rangee:(NSRange)range passwordLength:(NSInteger)length reqString:(nonnull NSString *)reqString;
-(BOOL) isValidAge : (NSString *_Nullable)age rangee:(NSRange)range ageLength:(NSInteger)length reqString:(nonnull NSString *)string;
@end
