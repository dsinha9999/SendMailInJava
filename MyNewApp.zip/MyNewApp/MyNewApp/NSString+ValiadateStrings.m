//
//  NSString+ValiadateStrings.m
//  MyNewApp
//
//  Created by Dharmendra Sinha on 28/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import "NSString+ValiadateStrings.h"

@implementation NSString (ValiadateStrings)

#pragma-mark Method to Verify Email
-(BOOL)isValidEmail : (NSString *)email rangee:(NSRange)range emailLength:(NSInteger)length reqString:(nonnull NSString *)reqString
{
    if ([reqString isEqualToString:@" "] || [reqString isEqualToString:@"@"])
    {
        if (!email.length)
            return NO;
        if ([[email stringByReplacingCharactersInRange:range withString:reqString] rangeOfString:@"  "].length)
            return NO;
    }
    if ([email stringByReplacingCharactersInRange:range withString:reqString].length < email.length) {
        return YES;
    }
    if ([email stringByReplacingCharactersInRange:range withString:reqString].length > length) {
        return NO;
    }
    NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@"0123456789_.@abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"];
    if ([reqString rangeOfCharacterFromSet:set].location == NSNotFound) {
        return NO;
    }
    return YES;
}

#pragma-mark Method to Validate Name
-(BOOL)isValidName : (NSString *_Nullable)name rangee:(NSRange)range nameLength:(NSInteger)length reqString:(nonnull NSString *)reqString
{
    if ([reqString isEqualToString:@" "]) {
        if (!name.length)
            return NO;
        if ([[name stringByReplacingCharactersInRange:range withString:reqString] rangeOfString:@"  "].length)
            return NO;
    }
    if ([name stringByReplacingCharactersInRange:range withString:reqString].length < name.length) {
        return YES;
    }
    if ([name stringByReplacingCharactersInRange:range withString:reqString].length > length) {
        return NO;
    }
    NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"];
    if ([reqString rangeOfCharacterFromSet:set].location == NSNotFound) {
        return NO;
    }
    return YES;
}

#pragma-mark Method to validate Mobile Number
-(BOOL) isMobileNumberValid : (NSString *_Nullable)mobile rangee:(NSRange)range mobileLength:(NSInteger)length reqString:(nonnull NSString *)reqString
{
    if ([mobile stringByReplacingCharactersInRange:range withString:reqString].length < mobile.length) {
        return YES;
    }
    if ([mobile stringByReplacingCharactersInRange:range withString:reqString].length > length) {
        return NO;
    }
    NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
    if ([reqString rangeOfCharacterFromSet:set].location == NSNotFound) {
        return NO;
    }
    return YES;
}

#pragma-mark Method to Validate Password
-(BOOL) isValidPassword : (NSString *_Nullable)password rangee:(NSRange)range passwordLength:(NSInteger)length reqString:(nonnull NSString *)reqString
{
    if ([reqString isEqualToString:@" "]) {
                    if (!password.length)
                        return NO;
                    if ([[password stringByReplacingCharactersInRange:range withString:reqString] rangeOfString:@"  "].length)
                        return NO;
                }
                if ([password stringByReplacingCharactersInRange:range withString:reqString].length < password.length) {
                    return YES;
                }
                if ([password stringByReplacingCharactersInRange:range withString:reqString].length > length) {
                    return NO;
                }
                NSCharacterSet *set = [NSCharacterSet alphanumericCharacterSet];
                if ([reqString rangeOfCharacterFromSet:set].location == NSNotFound) {
                    return NO;
                }
                return YES;
}

#pragma-mark Method To Valiadte Age
-(BOOL) isValidAge : (NSString *_Nullable)age rangee:(NSRange)range ageLength:(NSInteger)length reqString:(nonnull NSString *)string
{
    if ([string isEqualToString:@" "] || [string isEqualToString:@"0"]) {
        if (!age.length)
            return NO;
        if ([[age stringByReplacingCharactersInRange:range withString:string] rangeOfString:@"  "].length)
            return NO;
    }
    if ([age stringByReplacingCharactersInRange:range withString:string].length < age.length) {
        return YES;
    }
    if ([age stringByReplacingCharactersInRange:range withString:string].length > length) {
        return NO;
    }
    NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
    if ([string rangeOfCharacterFromSet:set].location == NSNotFound) {
        return NO;
    }
    return YES;
}
@end
