//
//  SignUpInfoM.h
//  MyNewApp
//
//  Created by Dharmendra Sinha on 26/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SignUpInfoM : NSObject

@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSString *age;
@property (strong, nonatomic) NSString *gender;
@property (strong, nonatomic) NSString *bio;
@property (strong, nonatomic) NSString *message;

+(SignUpInfoM *)initializeData;

@end
