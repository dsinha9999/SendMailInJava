//
//  SignUpInfoM.m
//  MyNewApp
//
//  Created by Dharmendra Sinha on 26/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import "SignUpInfoM.h"

@implementation SignUpInfoM

+(SignUpInfoM *)initializeData{
    SignUpInfoM *signUpInfoM = [[SignUpInfoM alloc] init];
    signUpInfoM.firstName = @"";
    signUpInfoM.lastName = @"";
    signUpInfoM.age = @"";
    signUpInfoM.gender = @"";
    signUpInfoM.bio = @"";
    signUpInfoM.message = @"";
    return signUpInfoM;
}

@end
