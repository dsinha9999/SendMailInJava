//
//  SignUpViewController.m
//  MyNewApp
//
//  Created by Dharmendra Sinha on 26/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import "SignUpViewController.h"
#import "NSString+ValiadateStrings.h"

@interface SignUpViewController ()<UITextFieldDelegate>
{
    NSString *emailString;
    NSString *emailReg;
    NSString *passwordString;
    NSString *passwordReg;
    NSPredicate *emailTest;
    NSPredicate *passwordTest;
}
@end

@implementation SignUpViewController

#pragma-mark viewDidLoad
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

#pragma-mark didReceiveMemoryWarning
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma-mark Touches Began
-(void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

#pragma-mark OnReturnKey
-(BOOL) textFieldShouldReturn:(UITextField *)textField
{
    [(UITextField *)[self.view viewWithTag:textField.tag+1] becomeFirstResponder];
    if(textField == self.repasswordField)
        [textField resignFirstResponder];
    return YES;
}

#pragma-mark UITextField Validation
-(BOOL) textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(nonnull NSString *)string
{
    if(textField == self.nameField)
    {
        if([textField.text isValidName:textField.text rangee:range nameLength:20 reqString:string])
            return YES;
        else
            return NO;
    }
    if(textField == self.emailField)
    {
        if([textField.text isValidEmail:textField.text rangee:range emailLength:25 reqString:string])
            return YES;
        else
            return NO;
    }
    if(textField == self.mobileField)
    {
        if([textField.text isMobileNumberValid:textField.text rangee:range mobileLength:10 reqString:string])
            return YES;
        else
            return NO;
    }
    if(textField == self.passwordField || textField == self.repasswordField)
    {
        if( [textField.text isValidPassword:textField.text rangee:range passwordLength:10 reqString:string])
            return YES;
        else
            return NO;
    }
    return YES;
}


-(void) textFieldDidBeginEditing:(UITextField *)textField
{
    if(textField == self.nameField)
    {
        [self.nameFieldErrorMessage setHidden:YES];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma-mark Method to go to Root ViewController
-(IBAction)backToViewController:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma-mark action on submit button
- (IBAction)submitButton:(id)sender {
    [self validateTextField];
}

#pragma-mark Validation on textFields
-(void) validateTextField
{
    emailString = self.emailField.text;
    emailReg = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    passwordString = self.passwordField.text;
    passwordReg = @"[a-zA-Z0-9]+";
    emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",emailReg];
    passwordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",passwordReg];
    
    if([self.nameField.text length] < 4)
    {
//        UIAlertController *nameAlert =[UIAlertController alertControllerWithTitle:@"Oops!!" message:@"Name Should Be 4 Characters Long" preferredStyle:UIAlertControllerStyleAlert];
//        UIAlertAction *nameButton = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
//            NSLog(@"Something Wrong");
//        }];
//        [nameAlert addAction:nameButton];
//        [self presentViewController:nameAlert animated:YES completion:nil];
//        self.nameField.rightViewMode = UITextFieldViewModeAlways;
//        self.nameField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"errorStar.png"]];
        self.nameFieldErrorMessage.text = @"Name Should Be 4 Characters Long";
    }
    if([self.emailField.text length] < 7)
    {
//        self.emailField.rightViewMode = UITextFieldViewModeAlways;
//        self.emailField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"errorStar.png"]];
        self.nameFieldErrorMessage.text = @"Email Should be more than 6 characters long";
    }
    if (([emailTest evaluateWithObject:emailString] != YES) || [emailString isEqualToString:@""])
    {
//        self.emailField.rightViewMode = UITextFieldViewModeAlways;
//        self.emailField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"errorStar.png"]];
        self.emailFieldErrorMessage.text = @"Enter Valid Email Id";
    }
    
    if([self.mobileField.text length] != 10)
    {
//        self.mobileField.rightViewMode = UITextFieldViewModeAlways;
//        self.mobileField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"errorStar.png"]];
        self.mobileErrorMessage.text = @"Mobile Number should be of 10 Digits";
    }
    if([self.passwordField.text length] < 8)
    {
//        self.passwordField.rightViewMode = UITextFieldViewModeAlways;
//        self.passwordField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"errorStar.png"]];
        self.passwordErrorMessage.text = @"Password must be of minimum 8 characters";
    }
    
    if(([passwordTest evaluateWithObject:passwordString] != YES ) || [passwordString isEqualToString:@""])
    {
//        self.passwordField.rightViewMode = UITextFieldViewModeAlways;
//        self.passwordField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"errorStar.png"]];
        self.passwordErrorMessage.text = @"Password must contain atleat one letter and 1 numeric value";
    }
    
    if([self.repasswordField.text length] < 8)
    {
//        self.repasswordField.rightViewMode = UITextFieldViewModeAlways;
//        self.repasswordField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"errorStar.png"]];
        self.repasswordErrorMessage.text = @"Password must be of minimum 8 characters";

    }
    if(([passwordTest evaluateWithObject:self.repasswordField.text] !=YES) || [self.repasswordField.text isEqualToString:@""] )
    {
//        self.repasswordField.rightViewMode = UITextFieldViewModeAlways;
//        self.repasswordField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"errorStar.png"]];
        self.repasswordErrorMessage.text = @"Password must contain atleat one letter and 1 numeric value";
    }
    if([self.passwordField text] != [self.repasswordField text])
    {

//        self.passwordField.rightViewMode = UITextFieldViewModeAlways;
//        self.passwordField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"errorStar.png"]];
//        self.repasswordField.rightViewMode = UITextFieldViewModeAlways;
//        self.repasswordField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"errorStar.png"]];
        self.repasswordField.text = @"Password didn't match";
    }
}
@end
