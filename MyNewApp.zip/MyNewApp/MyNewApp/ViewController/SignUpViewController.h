//
//  SignUpViewController.h
//  MyNewApp
//
//  Created by Dharmendra Sinha on 26/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SignUpInfoM.h"

@interface SignUpViewController : UIViewController<UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *nameField;
@property (strong, nonatomic) IBOutlet UILabel *nameFieldErrorMessage;
@property (strong, nonatomic) IBOutlet UITextField *emailField;
@property (strong, nonatomic) IBOutlet UILabel *emailFieldErrorMessage;
@property (strong, nonatomic) IBOutlet UITextField *mobileField;
@property (strong, nonatomic) IBOutlet UILabel *mobileErrorMessage;
@property (strong, nonatomic) IBOutlet UITextField *passwordField;
@property (strong, nonatomic) IBOutlet UILabel *passwordErrorMessage;
@property (strong, nonatomic) IBOutlet UITextField *repasswordField;
@property (strong, nonatomic) IBOutlet UILabel *repasswordErrorMessage;


@property (strong, nonatomic) SignUpInfoM *signUp;

@end
