//
//  AnotherViewController.m
//  MyNewApp
//
//  Created by Dharmendra Sinha on 27/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import "AnotherViewController.h"

@interface AnotherViewController ()<UITextFieldDelegate>

@end

@implementation AnotherViewController

#pragma-mark viewDidLoad
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
    // Do any additional setup after loading the view from its nib.
}


#pragma-mark initialSetup
-(void) initialSetup
{
    self.fnameField.text = _signUp2.firstName;
    self.lnameField.text = _signUp2.lastName;
    self.ageTextField.text = _signUp2.age;
    self.bioTextView.text = _signUp2.bio;
    self.messageLabel.text = [NSString stringWithFormat:@" Hello %@",_signUp2.firstName];
    if([_signUp2.gender isEqualToString:@"Male"])
        [(UIButton *) [self.view viewWithTag:1] setSelected:YES];
    if([_signUp2.gender isEqualToString:@"Female"])
        [(UIButton *) [self.view viewWithTag:2] setSelected:YES];
}

#pragma-mark textFieldShouldReturn
-(BOOL) textFieldShouldReturn:(UITextField *)textField
{
    [(UITextField *)[self.view viewWithTag:textField.tag+1] becomeFirstResponder];
    return YES;
}

#pragma-mark textViewShouldChangeTextInRange
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

#pragma-mark Touches Began
-(void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

#pragma-mark receiveMemoryWarning
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma-mark Method To Back To Root View
- (IBAction)goToRootViewController:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma-mark Male Button Action
- (IBAction)maleAction:(id)sender {
    UIButton *btn = (UIButton *)sender;
    btn.selected = !btn.selected;
    [(UIButton *) [self.view viewWithTag:2] setSelected:NO];
}

#pragma-mark Female Button Action
- (IBAction)femaleAction:(id)sender {
    UIButton *btn = (UIButton *)sender;
    btn.selected = !btn.selected;
    [(UIButton *) [self.view viewWithTag:1] setSelected:NO];
}
@end
