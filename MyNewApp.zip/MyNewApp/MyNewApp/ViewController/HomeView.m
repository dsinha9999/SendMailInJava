//
//  HomeView.m
//  MyNewApp
//
//  Created by Dharmendra Sinha on 27/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import "HomeView.h"
#import "ScrollViewTesting.h"
#import "DatePicker.h"
#import "ImagePicker.h"
@interface HomeView ()

@end

@implementation HomeView

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)backToRootViewController:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (IBAction)goToScrollViewTesting:(id)sender {
    ScrollViewTesting *scroll = [[ScrollViewTesting alloc] initWithNibName:@"ScrollViewTesting" bundle:nil];
    [self.navigationController pushViewController:scroll animated:YES];
}
- (IBAction)goToDatePicker:(id)sender {
    
    DatePicker *dPicker =[[DatePicker alloc] initWithNibName:@"DatePicker" bundle:nil];
    [self.navigationController pushViewController:dPicker animated:YES];
}
- (IBAction)goToImagePicker:(id)sender {
    ImagePicker *iPicker =[[ImagePicker alloc] initWithNibName:@"ImagePicker" bundle:nil];
    [self.navigationController pushViewController:iPicker animated:YES];
}

@end
