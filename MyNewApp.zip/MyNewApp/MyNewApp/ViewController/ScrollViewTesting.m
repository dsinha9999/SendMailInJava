//
//  ScrollViewTesting.m
//  MyNewApp
//
//  Created by Dharmendra Sinha on 27/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import "ScrollViewTesting.h"

@interface ScrollViewTesting ()<UIScrollViewDelegate>

@end

@implementation ScrollViewTesting

#pragma-mark ViewDidLoad
- (void)viewDidLoad {
    [super viewDidLoad];
    [self myScrollViewSetup];
    [self.navigationController setNavigationBarHidden:NO];
    // Do any additional setup after loading the view from its nib.
}

#pragma-mark ScrollView Setup
-(void) myScrollViewSetup
{
    myScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(10, 10, 395, 700)];
    myScroll.accessibilityActivationPoint = CGPointMake(100, 100);
    UIImageView *img = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"higres.jpg"]];
    [myScroll addSubview:img];
    myScroll.minimumZoomScale=0.3;
    myScroll.maximumZoomScale=3.0;
    myScroll.contentSize = CGSizeMake(img.frame.size.width, img.frame.size.height);
    CGFloat newContentOffsetX = (myScroll.contentSize.width - myScroll.frame.size.width) / 2;
    CGFloat newContentOffsetY = (myScroll.contentSize.height - myScroll.frame.size.height) / 2;
    myScroll.contentOffset = CGPointMake(newContentOffsetX, newContentOffsetY);
    myScroll.delegate = self;
    //[myScroll flashScrollIndicators];
    [self.view addSubview:myScroll];
    
}

#pragma-mark didReceiveMemoryWarning
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
