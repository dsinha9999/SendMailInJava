//
//  ViewController.h
//  MyNewApp
//
//  Created by Dharmendra Sinha on 25/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomUITextField.h"
#import "CustomUITextView.h"

@interface ViewController : UIViewController<UITextViewDelegate,UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *fnameTextField;
@property (strong, nonatomic) IBOutlet UITextField *lnameTextField;
@property (strong, nonatomic) IBOutlet UITextView *bioTextView;
@property (strong, nonatomic) IBOutlet UITextField *ageTextField;
@property (strong, nonatomic) IBOutlet UIButton *maleButton;
@property (strong, nonatomic) IBOutlet UIButton *femaleButton;

- (IBAction)maleAction:(id)sender;
- (IBAction)femaleAction:(id)sender;

@end
