//
//  ImagePicker.h
//  MyNewApp
//
//  Created by Dharmendra Sinha on 28/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImagePicker : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    UIImagePickerController *imagePicker;
    UIPopoverController *popOver;
}
@property (strong, nonatomic) IBOutlet UIImageView *imageView;
@property (strong, nonatomic) IBOutlet UIButton *galleryButton;
@property (strong, nonatomic) IBOutlet UIButton *cameraButton;

@end
