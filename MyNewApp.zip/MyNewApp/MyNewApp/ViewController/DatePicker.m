//
//  DatePicker.m
//  MyNewApp
//
//  Created by Dharmendra Sinha on 27/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import "DatePicker.h"
#import "HomeView.h"

@interface DatePicker ()<UITextFieldDelegate>

@end

@implementation DatePicker

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
    // Do any additional setup after loading the view from its nib.
}


-(void) initialSetup
{
    
    
    
    // Date Picker Creation
    datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 0, 430, 150)];
    datePicker.datePickerMode = UIDatePickerModeDate;
    [datePicker setDate:[NSDate date]];
    
    // Setting Minimum AND Maximum Date For DatePicker  min -> 01-Jan-1960  max -> 01-Jan-2000
    NSDateFormatter *minmaxFormatter =[[NSDateFormatter alloc] init];
    [minmaxFormatter setDateFormat:@"dd-MMM-yyyy"];
    NSString *min = @"01-Jan-1960";
    NSString *max = @"01-Jan-2000";
    NSDate *minDate = [minmaxFormatter dateFromString:min];
    NSDate *maxDate = [minmaxFormatter dateFromString:max];
    [datePicker setMinimumDate:minDate];
    [datePicker setMaximumDate:maxDate];
    
    
    // Toolbar Creation
    UIToolbar *toolbar =[[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 415, 35)];
    [toolbar setTintColor:[UIColor grayColor]];
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(showSelectedDate)];
    doneButton.tintColor = [UIColor grayColor];
    UIBarButtonItem *space = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleDone target:self action:@selector(cancelDateSelection)];
    [toolbar setItems:[NSArray arrayWithObjects:cancelButton,space,space,doneButton, nil]];
    
    //UI View With TOolbr and Date  Picker
    UIView *inputView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 430, toolbar.frame.size.height + datePicker.frame.size.height)];
    inputView.backgroundColor = [UIColor clearColor];
    [inputView addSubview:datePicker];
    [inputView addSubview:toolbar];
    [self.dateField setInputView:inputView];
}

#pragma-mark Show Selected Date
-(void) showSelectedDate
{
    NSDateFormatter *formatter =[[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd-MMM-yyyy"];
    self.dateField.text = [NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]];
    [self.dateField resignFirstResponder];
}

#pragma-mark cancel Selected Date
-(void) cancelDateSelection
{
    self.dateField.text = @"";
    [self.dateField resignFirstResponder];
}


-(void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.dateField endEditing:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)backToHomeView:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}

@end
