//
//  AnotherViewController.h
//  MyNewApp
//
//  Created by Dharmendra Sinha on 27/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SignUpInfoM.h"

@interface AnotherViewController : UIViewController<UITextFieldDelegate>

@property (strong, nonatomic) SignUpInfoM *signUp2;
@property (strong, nonatomic) IBOutlet UITextField *fnameField;
@property (strong, nonatomic) IBOutlet UITextField *lnameField;
@property (strong, nonatomic) IBOutlet UITextField *ageTextField;
@property (strong, nonatomic) IBOutlet UITextView *bioTextView;

@property (strong, nonatomic) IBOutlet UILabel *messageLabel;

@end
