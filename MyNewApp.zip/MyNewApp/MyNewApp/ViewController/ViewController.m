//
//  ViewController.m
//  MyNewApp
//
//  Created by Dharmendra Sinha on 25/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import "ViewController.h"
#import "MyHeader.h"
#import "NSString+ValiadateStrings.h"
#import "SignUpViewController.h"
#import "AnotherViewController.h"
#import "HomeView.h"
#import "SignUpInfoM.h"
#import "DatePicker.h"

@interface ViewController () <UITextFieldDelegate,UITextViewDelegate>{
    SignUpInfoM *signUp;
}

@end

@implementation ViewController

#pragma-mark  viewDidLoad
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetUp];
    [self.navigationController setNavigationBarHidden:YES];
}

#pragma-mark initial SetUp
-(void)initialSetUp{
    //Initialising model class
    signUp = [SignUpInfoM initializeData];
}

#pragma-mark  didReceiveMemoryWarning
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

#pragma-mark touchesBegan
-(void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

#pragma-mark textFieldShouldReturn
-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    [(UITextField *) [self.view viewWithTag:textField.tag+1] becomeFirstResponder];
    return YES;
}

#pragma-mark textViewShouldChangeTextInRange
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if([text isEqualToString:@"\n"]) {
        signUp.firstName = self.fnameTextField.text;
        signUp.lastName = self.lnameTextField.text;
        signUp.age = self.ageTextField.text;
        signUp.bio = textView.text;
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

#pragma-mark UITextField Validation
-(BOOL) textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(nonnull NSString *)string
{
    if(textField == self.fnameTextField || textField == self.lnameTextField)
    {
        if([textField.text isValidName:textField.text rangee:range nameLength:12 reqString:string])
            return YES;
        else
            return NO;
    }
    if(textField == self.ageTextField)
    {
        if([textField.text isValidAge:textField.text rangee:range ageLength:3 reqString:string])
            return YES;
        else
            return NO;
    }
    return YES;
}

#pragma-mark femaleAction
- (IBAction)femaleAction:(id)sender {
    UIButton *btn = (UIButton *)sender;
    btn.selected = !btn.selected;
    [(UIButton *)[self.view viewWithTag:200] setSelected:NO];
    if([(UIButton *)[self.view viewWithTag:201] isSelected])
        signUp.gender = @"Female";
    else
        signUp.gender = @"";
}

#pragma-mark maleAction
- (IBAction)maleAction:(id)sender {
    UIButton *btn = (UIButton *)sender;
    btn.selected = !btn.selected;
    [(UIButton *)[self.view viewWithTag:201] setSelected:NO];
    if([(UIButton *)[self.view viewWithTag:200] isSelected])
        signUp.gender = @"Male";
    else
        signUp.gender = @"";
}

#pragma-mark Method To go to SignUpViewController
- (IBAction)goToSignUp:(id)sender {
    SignUpViewController *signup = [[SignUpViewController alloc] initWithNibName:@"SignUpViewController" bundle:nil];
    [self.navigationController pushViewController:signup animated:YES];
    
}

#pragma-mark method to go to AnotherViewController
- (IBAction)forwardToAntotherViewController:(id)sender {
    AnotherViewController *anotherController = [[AnotherViewController alloc] initWithNibName:@"AnotherViewController" bundle:nil];
    anotherController.signUp2 = [[SignUpInfoM alloc]init];
    anotherController.signUp2 = signUp;
    [self.navigationController pushViewController:anotherController animated:YES];
}

#pragma-mark method to go to ScrollViewTesting
- (IBAction)goToScrollViewTesting:(id)sender {
    HomeView *scrollView = [[HomeView alloc] initWithNibName:@"HomeView" bundle:nil];
    [self.navigationController pushViewController:scrollView animated:YES];
}
@end
