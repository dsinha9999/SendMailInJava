//
//  main.m
//  MyNewApp
//
//  Created by Dharmendra Sinha on 25/07/17.
//  Copyright © 2017 Dharmendra Sinha. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
